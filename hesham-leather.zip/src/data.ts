import { Product } from './types';

export const exchangeRates = {
  YER: 1, // base
  USD: 1 / 1565, // 1 YER = 1/1565 USD
  SAR: 1 / 413,  // 1 YER = 1/413 SAR
};

export const products: Product[] = [
  {
    id: 'hsh-01',
    name: 'محفظة هِشام الكِلاسيكية',
    nameEn: 'HESHAM Regal Wallet',
    priceYer: 47000,
    description: 'محفظة جيب كلاسيكية مصنوعة كلياً من الجلد البقري الإيطالي الكامل المدبوغ طبيعياً بملمس معتق ورونق ملكي دائم.',
    detailedDescription: 'تأتي محفظة هِشام الكلاسيكية لتجسد المعنى الحقيقي للفخامة والعملية. تم دباغة الجلد بالمواد النباتية الطبيعية الخالية من الكيماويات لتكتسب المحفظة طابعاً معتقاً يزداد هيبة وجاذبية مع مرور الزمن. مخيطة يدوياً بخيوط شمعية فائقة المتانة لضمان جودة تدوم لأجيال.',
    images: [
      'https://images.unsplash.com/photo-1627124768124-04ef5850021b?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1588444837495-c6cfeb53f32d?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'wallets',
    leatherType: 'جلد بقري إيطالي كامل الحبوب (Full-Grain) دباغة نباتية فاخرة',
    dimensions: '11.5 سم × 9.5 سم × 1.5 سم',
    craftingTime: 'إعداد يدوي متقن (٢ - ٣ أيام عَمَل)',
    rating: 4.9,
    reviewsCount: 148,
    badge: 'الأكثر طلباً',
    colors: [
      { name: 'Tan Honey', nameAr: 'عسلي دافئ', hex: '#b87333' },
      { name: 'Classic Black', nameAr: 'أسود ملكي', hex: '#111111' },
      { name: 'Mahogany Brown', nameAr: 'بني عسلي غامق', hex: '#5c4033' }
    ]
  },
  {
    id: 'hsh-02',
    name: 'حقيبة اللابتوب والوثائق الملكية',
    nameEn: 'Royal Executive Briefcase',
    priceYer: 235000,
    description: 'حقيبة أعمال دبلوماسية راقية، مخصصة لرجال الحكمة والريادة، تجمع الهيبة العصرية مع دقة الخياطة اليدوية الفذّة.',
    detailedDescription: 'تمتع بمهابة لا تضاهى في اجتماعاتك. صُممت هذه الحقيبة لتتسع حاسوبًا بمقاس يصل إلى 16 بوصة، بالإضافة إلى جيب منظم للوثائق والأقلام ونظارتك الخاصة. مجهزة بقفل نحاسي مشفر مطلي بماء الذهب العتيق المقاوم للصدأ والتآكل.',
    images: [
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'bags',
    leatherType: 'جلد البقر البريميوم السميك المعالج بشمع النحل الطبيعي لجمال معتق',
    dimensions: '39 سم × 30 سم × 8.5 سم',
    craftingTime: 'إعداد يدوي متقن (5 - 7 أيام عمل)',
    rating: 5.0,
    reviewsCount: 64,
    badge: 'إصدار محدود',
    colors: [
      { name: 'Deep Cognac', nameAr: 'كوجناك مهيب', hex: '#8c5230' },
      { name: 'Noir Absolute', nameAr: 'أسود فاحم', hex: '#1a1a1a' }
    ]
  },
  {
    id: 'hsh-03',
    name: 'حزام هِشام الدبلوماسي النخبة',
    nameEn: 'Elite Bridle Leather Belt',
    priceYer: 39000,
    description: 'حزام جلدي ذو هيبة واضحة، مصنوع من طبقة واحدة سميكة ومصقولة يدوياً لمتانة أسطورية وإطلالة تفرض الاحترام.',
    detailedDescription: 'التفاصيل الصغيرة هي ما تصنع الفارق العظيم. يتميز حزام النخبة بإبزيم نحاسي مصقول يدوياً باللون الفضي العتيق أو الذهبي الهادئ، مع حواف ملساء وحافة بنقش غائر خفي مميز. صلب بما يكفي ليدوم عمراً، ومرن بما يكفي ليوفر الراحة الكلية.',
    images: [
      'https://images.unsplash.com/photo-1624222247344-550fb8b22e11?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'accessories',
    leatherType: 'جلد لجام إنجليزي مدفوع الشحوم والزيوت الطبيعية لمقاومة قصوى',
    dimensions: 'عرض ٣.٨ سم (طول مخصص حسب قياس الخصر)',
    craftingTime: 'إعداد يدوي متقن (١ - ٢ يوم عمل)',
    rating: 4.8,
    reviewsCount: 205,
    colors: [
      { name: 'Rich Mahogany', nameAr: 'بني شوكولاتة', hex: '#3d251e' },
      { name: 'Black Onyx', nameAr: 'أسود معتم', hex: '#0a0a0a' },
      { name: 'Warm Tan', nameAr: 'بني عسلي', hex: '#a66a38' }
    ]
  },
  {
    id: 'hsh-04',
    name: 'علبة ساعات النُخبة المخملية',
    nameEn: 'Imperial Watch Keeper',
    priceYer: 85000,
    description: 'خزينة جلدية يدوية مخصصة لحفظ ٣ ساعات من الساعات الثمينة، ببطانة مخملية مخيطة يدوياً لمنع الخدوش والدست المترب.',
    detailedDescription: 'تستحق ساعاتك الفخمة موطناً من الهيبة تليق بمكانتها. تأتي علبة الساعات من HESHAM بشكل أسطواني صلب يوفر الحماية الكاملة مع فواصل قابلة للإزالة وبطانة من قماش الشامواه الناعم الفاخر، لتكون رفيقة مثالية في رحلاتك الفاخرة أو على منضدة غرفتك الخاصة.',
    images: [
      'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1547996160-81dfa63595aa?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'boxes',
    leatherType: 'جلد الماعز الإسباني المصقول مع قاعدة خشبية طبيعية صلبة للحماية',
    dimensions: '٢٢ سم × ١٠ سم × ٧.٥ سم',
    craftingTime: 'إعداد يدوي متقن (٣ - ٤ أيام عمل)',
    rating: 4.9,
    reviewsCount: 51,
    badge: 'مفضل لهدايا كبار الشخصيات',
    colors: [
      { name: 'Midnight Blue', nameAr: 'كحلي دوقي', hex: '#1d2a44' },
      { name: 'English Green', nameAr: 'أخضر غابات ملكي', hex: '#1c352d' },
      { name: 'Camel Tan', nameAr: 'جملي دافئ', hex: '#c19a6b' }
    ]
  },
  {
    id: 'hsh-05',
    name: 'محفظة البطاقات الصّغيرة الهندسية',
    nameEn: 'HESHAM Origami Cardholder',
    priceYer: 24000,
    description: 'محفظة كروت ذكية وسريعة الحفظ، مصممة بهندسة مدمجة خالية من الدرزات الكثيفة لتوفير مظهر غاية في البساطة وعصرية فائقة.',
    detailedDescription: 'صُممت هذه الحافظة لعشّاق الخيارات الحديثة والمدمجة. فبتقنية فريدة للقص والطي والتثبيت ببرشام مخفي، تتسع لـ ٦ كروت بالإضافة للمبالغ النقدية المطوية بشكل أنيق ومريح في جيبك الأمامي دون أي بروز مزعج.',
    images: [
      'https://images.unsplash.com/photo-1588444837495-c6cfeb53f32d?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1627124768124-04ef5850021b?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'wallets',
    leatherType: 'جلد بقري رفيع مشدود ومرن بمقاومة قصوى ضد الخدوش والماء',
    dimensions: '10.2 سم × 6.8 سم × 0.8 سم',
    craftingTime: 'إعداد يدوي متقن (١ - ٢ يوم عمل)',
    rating: 4.7,
    reviewsCount: 192,
    colors: [
      { name: 'Tobacco Leaf', nameAr: 'عسلي محروق', hex: '#a0522d' },
      { name: 'Asphalt Gray', nameAr: 'رمادي مسحوق', hex: '#4d4d4d' },
      { name: 'Sovereign Black', nameAr: 'أسود مخملي', hex: '#151515' }
    ]
  },
  {
    id: 'hsh-06',
    name: 'مفكرة وغلاف ريادة المانِيفستو',
    nameEn: 'Manifesto Executive Journal Cover',
    priceYer: 68000,
    description: 'غلاف جلدي فخم للمفكرات والدفاتر قابل لإعادة التعبئة أبدياً، منقوش بلطف وبلمسة تعبق بالتاريخ والوقار لكتابة رؤيتك الخاصة.',
    detailedDescription: 'كل فكرة متميزة تبدأ بكتابة رصينة. سيجعل غلاف Manifesto تجربة الكتابة فصلاً يومياً فخماً، ترافقه مفكرة عالية النقاء 100gsm وحامل مخصص لأقلام الحبر النادرة وجيوب فرعية لبطاقات الأعمال وتمرير المستندات السرية.',
    images: [
      'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'accessories',
    leatherType: 'جلد سويدي مخملي عتيق مع وجه خارجي صلب ناعم الملمس بقوام فخم',
    dimensions: 'A5 (22.5 سم × 16 سم × 2.0 سم)',
    craftingTime: 'إعداد يدوي متقن (٢ - ٣ أيام عمل)',
    rating: 4.9,
    reviewsCount: 88,
    badge: 'منتج خاص للإهداء',
    colors: [
      { name: 'Vintage Oak', nameAr: 'بني عتيق مستشرق', hex: '#6f4f28' },
      { name: 'Oxford Burgundy', nameAr: 'عنبي إنجليزي فخم', hex: '#631024' }
    ]
  },
  {
    id: 'hsh-07',
    name: 'حقيبة مستحضرات الحلاقة والعناية للسفر',
    nameEn: 'Admiralty Grooming Washbag',
    priceYer: 95000,
    description: 'حقيبة سفر صلبة لمحيط الحلاقة والعناية الشخصية، ببطانة مقاومة للماء لحماية أغراضك بأناقة لا غبار عليها.',
    detailedDescription: 'لتكون رحلاتك برونق ووقار تام، صُممت حقيبة مستندات العناية لتستوعب كافة أدواتك الشخصية. تأتي مع قاعدة صلبة لتثبيتها على أي سطح بطريقة ثابتة، وبسحاب معدني ألماني متين مغطى بالكامل بطبقة حماية جلدية.',
    images: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'bags',
    leatherType: 'جلد العجل الإيطالي المشبع بالزيوت لملمس شديد النعومة واللمعان الهادئ',
    dimensions: '٢٥ سم × ١٣ سم × ١٢ سم',
    craftingTime: 'إعداد يدوي متقن (٣ - ٥ أيام عمل)',
    rating: 4.8,
    reviewsCount: 42,
    colors: [
      { name: 'Classic Tan', nameAr: 'بني جملي كلاسيك', hex: '#ad724a' },
      { name: 'Gentleman Noir', nameAr: 'أسود السادة النبلاء', hex: '#161616' }
    ]
  },
  {
    id: 'hsh-08',
    name: 'حقيبة العطلات والسفر الكراندير',
    nameEn: 'HESHAM Grand Duffle Bag',
    priceYer: 380000,
    description: 'الحقيبة الأكبر حجماً والأكثر رقيّاً من مشغلاتنا اليدوية، صُممت لمن يقدر السفر بوقار وأسلوب يثير التقدير والدهشة.',
    detailedDescription: 'تأخذك هذه الحقيبة إلى حقبة السفر الذهبية المليئة بالاحترام والذوق الرفيع. مساحة هائلة مبطنة بأرقى المنسوجات، وجيب مخفي خاص بالعملات والمجوهرات، مع حزام عريض مبطن ومريح للأكتاف مصنوع بالكامل من جلد البقر الإيطالي والخطافات النحاسية الثقيلة المصمتة.',
    images: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'bags',
    leatherType: 'جلد بقري كامل الحبوب فائق الجودة، سماكة ٢.٤ مم لمقاومة أبدية للظروف والمناخ والترحال الدائم',
    dimensions: '٥٢ سم × ٢٨ سم × ٢٨ سم',
    craftingTime: 'إعداد يدوي متقن (١٠ - ١٢ يوم عمل)',
    rating: 5.0,
    reviewsCount: 19,
    badge: 'تصميم أيقوني شاهق الأثر',
    colors: [
      { name: 'Saddle Tan', nameAr: 'عسلي محروق أيل', hex: '#874110' },
      { name: 'Night Onyx', nameAr: 'سواد منتصف الليل', hex: '#000000' }
    ]
  }
];
