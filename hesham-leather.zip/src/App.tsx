import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, 
  Sun, 
  Moon, 
  ShoppingCart, 
  X, 
  Plus, 
  Minus, 
  Check, 
  Star, 
  Sparkles, 
  Globe, 
  MessageCircle, 
  Layers, 
  BookOpen, 
  Truck, 
  ShieldCheck, 
  ArrowRight,
  Info,
  Clock,
  Briefcase,
  Heart,
  ChevronLeft,
  ChevronRight,
  ArrowUpRight
} from 'lucide-react';
import { products, exchangeRates } from './data';
import { Product, CartItem, CurrencyType, CustomOrder } from './types';

export default function App() {
  // Theme & Dark Mode State (default to dark mode for luxury "fahm" look, but user can toggle)
  const [darkMode, setDarkMode] = useState<boolean>(true);
  
  // Currency State
  const [currency, setCurrency] = useState<CurrencyType>('YER');
  
  // Shopping Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  
  // Selected Category filter
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  // Active product for detail modal
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Active configuration for detail modal
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [customEngraving, setCustomEngraving] = useState<string>('');
  const [modalImageIndex, setModalImageIndex] = useState<number>(0);

  // Custom Order Desk State
  const [customOrder, setCustomOrder] = useState<CustomOrder>({
    clientName: '',
    accessoryType: 'محفظة بطلب خاص',
    leatherColor: 'هافان / بني عسلي',
    engravingText: '',
    details: '',
    urgency: 'normal'
  });
  const [customOrderSubmitted, setCustomOrderSubmitted] = useState<boolean>(false);

  // Active feedback notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Apply dark mode theme to document
  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  // Utility to fire temporary toast notification
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Convert and Format Prices with elegant local and international design
  const formatPrice = (priceYer: number) => {
    if (currency === 'USD') {
      const converted = priceYer * exchangeRates.USD;
      return `${converted.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} $`;
    } else if (currency === 'SAR') {
      const converted = priceYer * exchangeRates.SAR;
      return `${converted.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} ﷼.س`;
    } else {
      return `${priceYer.toLocaleString('ar-YE')} ﷼.ي`;
    }
  };

  // Switch Currency Rates Label
  const getCurrencyName = () => {
    if (currency === 'USD') return 'الدولار الأمريكي';
    if (currency === 'SAR') return 'الريال السعودي';
    return 'الريال اليمني';
  };

  // Filter products by category
  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  // Cart operations
  const addToCart = (product: Product, color: string, engraving: string, navigateToCart = false) => {
    const chosenColor = color || product.colors[0].nameAr;
    const existingIndex = cart.findIndex(
      item => item.product.id === product.id && 
              item.selectedColor === chosenColor && 
              item.customEngraving === engraving
    );

    if (existingIndex > -1) {
      const updatedCart = [...cart];
      updatedCart[existingIndex].quantity += 1;
      setCart(updatedCart);
    } else {
      setCart([...cart, { product, quantity: 1, selectedColor: chosenColor, customEngraving: engraving }]);
    }

    triggerToast(`تمت إضافة "${product.name}" بنجاح إلى سلتك الفاخرة`);
    
    if (navigateToCart) {
      setIsCartOpen(true);
    }
  };

  const updateQuantity = (index: number, delta: number) => {
    const updated = [...cart];
    updated[index].quantity += delta;
    if (updated[index].quantity <= 0) {
      updated.splice(index, 1);
      triggerToast('تمت إزالة المنتج من سلتك');
    }
    setCart(updated);
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + (item.product.priceYer * item.quantity), 0);
  };

  const getCartItemCount = () => {
    return cart.reduce((count, item) => count + item.quantity, 0);
  };

  // Open modal config
  const openProductModal = (product: Product) => {
    setSelectedProduct(product);
    setSelectedColor(product.colors[0].nameAr);
    setCustomEngraving('');
    setModalImageIndex(0);
  };

  // Formulate WhatsApp order for a single item (Buy Now instantly)
  const sendInstantWhatsAppOrder = (product: Product, color: string, engraving: string) => {
    const activeColor = color || product.colors[0].nameAr;
    const engravingDetail = engraving.trim() ? engraving : 'لا يوجد (بدون حفر)';
    const formattedPrice = formatPrice(product.priceYer);
    
    const messageText = `السلام عليكم يا متجر هِشام لِلمصنوعات الجلدية الفاخرة 🌹
أود شراء هذا المُنْتَج الفاخر من متجركم الإلكتروني:

💎 المُنْتَج: ${product.name} (${product.nameEn})
🎨 اللون المحدد: ${activeColor}
✍️ ميزة الحفر الشخصي: ${engravingDetail}
💰 السعر المحدد: ${formattedPrice}
📦 زمن الصنع والتحضير: ${product.craftingTime}

أرجو تأكيد استلام الطلب وتزويدي بطريقة الدفع وعنوان التوصيل الفاخر. شكراً لكم!`;

    const encodedMessage = encodeURIComponent(messageText);
    const whatsappUrl = `https://wa.me/967780066128?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  // Formulate WhatsApp order for the entire cart
  const sendCartWhatsAppOrder = () => {
    if (cart.length === 0) return;
    
    let itemsDescription = '';
    cart.forEach((item, index) => {
      const priceScaled = formatPrice(item.product.priceYer * item.quantity);
      const engravingDetail = item.customEngraving ? item.customEngraving : 'لا يوجد';
      itemsDescription += `📦 [${index + 1}] ${item.product.name}\n  - اللون: ${item.selectedColor}\n  - الحفر الشخصي والاسم: ${engravingDetail}\n  - الكمية: ${item.quantity}\n  - السعر: ${priceScaled}\n\n`;
    });

    const totalOrderPrice = formatPrice(getCartTotal());
    
    const messageText = `السلام عليكم يا متجر هِشام لِلمصنوعات الجلدية الفاخرة 👋
أود إتمام طلب شراء السلة الفاخرة التالية من موقعكم وبدء تصنيعها يدوياً:

🧾 تفاصيل ومحتوى السلة الفاخرة:
------------------------------------------
${itemsDescription}------------------------------------------
📊 الإجمالي الكلي للطلب الفاخر: ${totalOrderPrice}
💳 العملة المعتمدة: ${getCurrencyName()} (${currency})

📍 يرجى تأكيد استلام تفاصيل سلة المشتريات لتزويدي بحسابات التحويل ومتابعة الشحن والتوصيل.`;

    const encodedMessage = encodeURIComponent(messageText);
    const whatsappUrl = `https://wa.me/967780066128?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  // Formulate WhatsApp for custom personalized order
  const sendCustomOrderWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customOrder.clientName.trim() || !customOrder.details.trim()) {
      triggerToast('رجاءً املأ اسمك وتفاصيل مواصفات المنفعة الجلدية');
      return;
    }

    const urgencyLabel = customOrder.urgency === 'express' ? 'مستعجل (أولوية فائقة مع علبة إهداء خاصة)' : 'عادي (صناعة متقنة متمهلة)';
    const engraving = customOrder.engravingText.trim() ? customOrder.engravingText : 'لا يوجد';

    const messageText = `السلام عليكم يا متجر هِشام لِلمصنوعات الجلدية الفاخرة 🎨✨
أود تقديم طلب تفصيل قطعة مصنوعات جلدية مخصصة ومصممة خصيصاً لي:

🛠️ تفاصيل استمارة الطلب المخصص:
------------------------------------------
👤 اسم صاحب الطلب: ${customOrder.clientName}
🎒 نوع القطعة الجلدية: ${customOrder.accessoryType}
🎨 لون الجلد المرغوب: ${customOrder.leatherColor}
✍️ حفر الاسم بالليزر: ${engraving}
⏳ الأولوية وعجلة الصنع: ${urgencyLabel}
📝 التفاصيل، الأبعاد والمنافع الإضافية:
"${customOrder.details}"
------------------------------------------

أرجو الاطلاع على مواصفات الطلب وإشعاري بدراسة التنفيذ، التكلفة التقديرية بالريال اليمني/الدولار وسعر الصرف، وكافة التفاصيل لبدء صقلها يدوياً. دُمتم بحفظ الله!`;

    const encodedMessage = encodeURIComponent(messageText);
    const whatsappUrl = `https://wa.me/967780066128?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
    setCustomOrderSubmitted(true);
    triggerToast('تم تحويل طلبك الخاص للوتساب بنجاح');
  };

  return (
    <div className={`min-h-screen font-sans ${darkMode ? 'dark bg-[#0b0c10] text-[#eae9e6]' : 'bg-[#faf9f5] text-[#242320]'} selection:bg-[#c5a059] selection:text-black`}>
      
      {/* 1. Global Micro Toast System */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9, y: -20 }}
            className="fixed top-6 left-1/2 -translate-x-1/2 z-50 px-6 py-4 bg-stone-900 text-stone-100 dark:bg-stone-100 dark:text-stone-900 shadow-2xl rounded-xl border border-amber-500/20 flex items-center gap-3 backdrop-blur-md max-w-sm text-center"
            id="global-toast"
          >
            <Sparkles className="w-5 h-5 text-[#c5a059] shrink-0" />
            <p className="text-sm font-medium leading-relaxed">{toastMessage}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. Top Banner / Header Announcement with Floating Light */}
      <div className="bg-[#111111] text-xs text-stone-400 py-2 px-4 text-center border-b border-stone-800 flex flex-wrap gap-x-6 gap-y-1 justify-center items-center z-40 relative">
        <span className="flex items-center gap-1 text-[#c5a059] font-medium border-l border-stone-800 pl-4">
          <Truck className="w-3.5 h-3.5" /> توصيل سريع ومحترم لجميع المحافظات اليمنية وخارجها
        </span>
        <span className="flex items-center gap-1 font-mono">
          <Globe className="w-3.5 h-3.5" /> أسعار الصرف الحالية المعتمدة: $1 = 1565 ر.ي | ﷼.س1 = 413 ر.ي
        </span>
      </div>

      {/* 3. Luxury Navigation Bar */}
      <header className="sticky top-0 z-40 backdrop-blur-stone duration-300 border-b transition-all border-stone-200/50 bg-[#faf9f5]/90 dark:border-stone-900/60 dark:bg-[#0b0c10]/95 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 md:h-24 flex items-center justify-between">
          
          {/* Right Section: Mobile menu button / Theme / Currency Switches */}
          <div className="flex items-center gap-3 md:gap-4">
            {/* Dark & Light toggle */}
            <button 
              id="theme-toggler"
              onClick={() => setDarkMode(!darkMode)}
              className="p-2.5 rounded-lg border border-stone-300 dark:border-stone-800 text-stone-600 dark:text-stone-300 bg-stone-100/40 dark:bg-stone-950/40 hover:bg-stone-100 dark:hover:bg-stone-900 transition-colors duration-200"
              title="تفعيل الوضع الداكن / الفخم"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-stone-800" />}
            </button>

            {/* Currency Selector */}
            <div className="relative flex items-center bg-stone-100 dark:bg-stone-950 rounded-lg p-1 border border-stone-300 dark:border-stone-800" id="currency-picker-container">
              {(['YER', 'USD', 'SAR'] as CurrencyType[]).map((cur) => (
                <button
                  key={cur}
                  onClick={() => {
                    setCurrency(cur);
                    triggerToast(`تم تحويل عرض الأسعار لعملة: ${cur === 'YER' ? 'الريال اليمني' : cur === 'USD' ? 'الدولار الأمريكي' : 'الريال السعودي'}`);
                  }}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all duration-200 ${
                    currency === cur 
                      ? 'bg-[#c5a059] text-stone-950 shadow-sm' 
                      : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-100'
                  }`}
                  id={`currency-btn-${cur}`}
                >
                  {cur === 'YER' ? '﷼.ي' : cur === 'USD' ? 'USD' : '﷼.س'}
                </button>
              ))}
            </div>
          </div>

          {/* Center Section: Sublime Brand Identity */}
          <div className="text-center">
            <a href="#" className="inline-block group">
              <h1 className="text-2xl md:text-3.5xl font-serif tracking-[0.25em] md:tracking-[0.35em] text-stone-950 dark:text-white font-black leading-tight select-none">
                HESHAM
              </h1>
              <div className="flex items-center justify-center gap-2 mt-1">
                <span className="w-4 h-[1px] bg-[#c5a059]"></span>
                <p className="text-[9px] md:text-[10px] tracking-[0.4em] font-serif uppercase text-[#c5a059] font-semibold">
                  Crafted Leather
                </p>
                <span className="w-4 h-[1px] bg-[#c5a059]"></span>
              </div>
            </a>
          </div>

          {/* Left Section: Nav Links & Dynamic Shopping Cart Drawer Link */}
          <div className="flex items-center gap-4">
            {/* Custom Atelier Link */}
            <a 
              href="#bespoke-studio"
              className="hidden lg:flex items-center gap-1.5 text-xs font-semibold text-[#c5a059] tracking-wider hover:text-[#d9b775] transition-colors uppercase border border-[#c5a059]/20 rounded-full px-4 py-2 bg-[#c5a059]/5 hover:bg-[#c5a059]/10"
              id="atelier-link"
            >
              <Sparkles className="w-3.5 h-3.5 animate-pulse" /> صالون التفصيل الخاص
            </a>

            {/* Shopping Cart Trigger */}
            <button
              id="cart-trigger"
              onClick={() => setIsCartOpen(true)}
              className="relative p-3 rounded-lg border border-stone-300 dark:border-stone-800 text-stone-800 dark:text-stone-200 bg-stone-100/40 dark:bg-stone-950/40 hover:bg-stone-100 dark:hover:bg-stone-900 transition-all duration-300 flex items-center gap-2 group"
            >
              <span className="relative">
                <ShoppingBag className="w-5 h-5 group-hover:scale-105 duration-200" />
                {getCartItemCount() > 0 && (
                  <span className="absolute -top-2.5 -right-2.5 w-5 h-5 bg-amber-500 text-stone-950 text-[10px] font-black rounded-full flex items-center justify-center animate-bounce border-2 border-[#faf9f5] dark:border-[#0b0c10]" id="cart-badge-count">
                    {getCartItemCount()}
                  </span>
                )}
              </span>
              <span className="text-xs font-bold hidden sm:inline-block tracking-wider">السلة الفاخرة</span>
            </button>
          </div>

        </div>
      </header>

      {/* 4. Elegant Hero Theater Section */}
      <section className="relative overflow-hidden py-16 md:py-24 border-b border-stone-200/40 dark:border-stone-900/60" id="hero-theater">
        {/* Ambient graphic backdrops */}
        <div className="absolute top-0 left-0 w-80 h-80 bg-amber-600/5 rounded-full filter blur-[100px] pointer-events-none"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-amber-700/5 rounded-full filter blur-[120px] pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Right side: Cinematic Text copy */}
            <div className="lg:col-span-7 space-y-6 text-right order-2 lg:order-1">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-[#c5a059] text-xs font-bold tracking-wider float-right mb-2">
                <Sparkles className="w-3.5 h-3.5" /> هندسة الأناقة المتمردة على فناء الزمن
              </div>
              <div className="clear-both"></div>
              
              <h2 className="text-3.5xl md:text-5.5xl font-black font-serif text-stone-950 dark:text-white leading-[1.15] tracking-tight">
                أعمال جلدية يدوية تحمل <span className="gold-gradient-text text-glow">هيبَتك وتدوم أجيالاً</span>
              </h2>
              
              <p className="text-base md:text-lg text-stone-600 dark:text-stone-300 leading-relaxed font-light">
                مزيج من الدباغة العتيقة وحرفيّة التشكيل الفريد لزبائن متجر <span className="font-bold text-stone-900 dark:text-white">HESHAM</span>. قطع ملموسة تُصقل لك باليد لتروي قصة من الوقار، وترافقك كعشيق وفي يزداد فخامة وجاذبية مع بزوغ فصول السنين.
              </p>

              {/* USP List */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 text-stone-600 dark:text-stone-300">
                <div className="flex items-center gap-2 bg-stone-100/50 dark:bg-stone-900/40 p-3 rounded-lg border border-stone-200/50 dark:border-stone-800">
                  <ShieldCheck className="w-5 h-5 text-[#c5a059] shrink-0" />
                  <span className="text-xs font-bold">جلد بقري إيطالي أصيل 100%</span>
                </div>
                <div className="flex items-center gap-2 bg-stone-100/50 dark:bg-stone-900/40 p-3 rounded-lg border border-stone-200/50 dark:border-stone-800">
                  <Clock className="w-5 h-5 text-[#c5a059] shrink-0" />
                  <span className="text-xs font-bold">حفر اسمك بالحرارة مجاناً</span>
                </div>
                <div className="flex items-center gap-2 bg-stone-100/50 dark:bg-stone-900/40 p-3 rounded-lg border border-stone-200/50 dark:border-stone-800">
                  <MessageCircle className="w-5 h-5 text-[#c5a059] shrink-0" />
                  <span className="text-xs font-bold">طلب فوري مخصص عبر الواتساب</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-4 pt-6 justify-start font-bold">
                <a
                  href="#collection-gallery"
                  className="px-8 py-4 bg-stone-950 dark:bg-stone-100 text-[#faf9f5] dark:text-[#0b0c10] text-sm tracking-wider rounded-xl hover:bg-stone-800 dark:hover:bg-stone-200 transition-all duration-300 shadow-xl flex items-center gap-2 group scale-100 hover:scale-105 active:scale-95"
                >
                  استكشف المعرض الفاخر
                  <ArrowRight className="w-4 h-4 text-[#c5a059] group-hover:translate-x-1 transition-transform" />
                </a>
                <a
                  href="#bespoke-studio"
                  className="px-8 py-4 border-2 border-stone-300 dark:border-stone-800 hover:border-stone-400 dark:hover:border-stone-700 text-stone-800 dark:text-stone-200 text-sm tracking-wider rounded-xl transition-all duration-300 flex items-center gap-2 hover:bg-stone-100/40 dark:hover:bg-stone-900/40"
                >
                  طلب تفصيل خاص مخصص
                </a>
              </div>
            </div>

            {/* Left side: Luxury Mockup showcase with double image layering */}
            <div className="lg:col-span-5 order-1 lg:order-2 flex justify-center">
              <div className="relative w-full max-w-[340px] sm:max-w-[400px]" id="luxury-image-layering">
                
                {/* Main Image Frame with Gold border */}
                <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl border-2 border-[#c5a059]/40 aspect-[4/5] bg-stone-950 group">
                  <img 
                    src="https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&q=80&w=800"
                    alt="صناعة جلدية يدوية فخمة"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out brightness-90 group-hover:brightness-100"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent"></div>
                  
                  {/* Floating Micro Detail inside Hero Image */}
                  <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl backdrop-blur-md bg-stone-950/70 border border-stone-800/80 text-right text-[#eae9e6] shadow-2xl">
                    <p className="text-[10px] tracking-widest text-[#c5a059] font-mono leading-none">CRAFTED ACCURACY</p>
                    <h4 className="text-sm font-bold mt-1">حقيبة اللابتوب والوثائق الملكية</h4>
                    <p className="text-xs text-stone-400 mt-1">جلد معالج بأمهار الشمع والخلطات الإيطالية القديمة لحماية قصوى وسعة ملكية هادئة.</p>
                  </div>
                </div>

                {/* Second Layer offset card behind */}
                <div className="absolute -top-6 -left-6 w-full h-full rounded-2xl border border-stone-300 dark:border-stone-900 bg-stone-100/40 dark:bg-stone-950/40 -z-10 transform -rotate-3 transition-transform duration-500 hover:rotate-0"></div>
                
                {/* Visual badge hanging on wire */}
                <div className="absolute -top-3 right-6 bg-[#c5a059] text-stone-950 px-4 py-2 rounded-lg text-[10px] font-black tracking-widest uppercase transform rotate-6 shadow-xl z-20">
                  طرز ملكي متميّز
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 5. Workshop Excellence Badges */}
      <section className="py-10 bg-stone-100/50 dark:bg-stone-950/50 border-b border-stone-200/40 dark:border-stone-900/60" id="brand-pillars">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 gap-y-10">
            
            <div className="text-center space-y-2">
              <div className="w-12 h-12 bg-[#c5a059]/10 text-[#c5a059] rounded-xl flex items-center justify-center mx-auto border border-[#c5a059]/20">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold">جلد طبيعي للأبد</h4>
              <p className="text-xs text-stone-500 dark:text-stone-400 max-w-[200px] mx-auto">إنتقاء صارم لجلد سوبر بقري كامل الحبيبات بنفاذ رطوبة ممتاز وقدرات مرنة.</p>
            </div>

            <div className="text-center space-y-2">
              <div className="w-12 h-12 bg-[#c5a059]/10 text-[#c5a059] rounded-xl flex items-center justify-center mx-auto border border-[#c5a059]/20">
                <Sparkles className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold">خياطة يدوية سدجية</h4>
              <p className="text-xs text-stone-500 dark:text-stone-400 max-w-[200px] mx-auto">نعتمد دقة تامة بالدرز المزدوج لقطع لا تخرج خيوطها أبدًا ومشدودة بإحكام عالي.</p>
            </div>

            <div className="text-center space-y-2">
              <div className="w-12 h-12 bg-[#c5a059]/10 text-[#c5a059] rounded-xl flex items-center justify-center mx-auto border border-[#c5a059]/20">
                <Clock className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold">تخصيص كامل الحروف</h4>
              <p className="text-xs text-stone-500 dark:text-stone-400 max-w-[200px] mx-auto">احصل على حروف اسمك محفورة بالكبس الحراري الذهبي أو الفضي أو الحفر الغائر الخالد.</p>
            </div>

            <div className="text-center space-y-2">
              <div className="w-12 h-12 bg-[#c5a059]/10 text-[#c5a059] rounded-xl flex items-center justify-center mx-auto border border-[#c5a059]/20">
                <MessageCircle className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold">تواصل مباشر واتساب</h4>
              <p className="text-xs text-stone-500 dark:text-stone-400 max-w-[200px] mx-auto">نقوم بإعداد رسائل الطلبات تلقائياً مع تفاصيلها لمحادثات واتساب سلسة وسريعة للبدء فوراً.</p>
            </div>

          </div>
        </div>
      </section>

      {/* 6. Dynamic Main Shop Gallery */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="collection-gallery">
        
        {/* Title & Filter Selection Head */}
        <div className="text-center space-y-4 mb-16">
          <span className="text-xs font-serif uppercase tracking-[0.3em] text-[#c5a059] font-bold">Exclusive Catalog</span>
          <h3 className="text-2.5xl md:text-4.5xl font-serif text-stone-950 dark:text-white font-extrabold tracking-tight">
            مَجموعتنا الجلديّة المعروضة للصّقل
          </h3>
          <p className="text-sm md:text-base text-stone-500 dark:text-stone-400 max-w-2xl mx-auto">
            انقر على أي منتج لاستعراض كافّة تفاصيله والمواد المستخدمة فيه، وتخصيص نقش حروف اسمك واختيار ظلال اللون، ثم إرساله فوراً لسلتك أو لواتساب المتجر لبدء التحضير.
          </p>

          {/* Filtering buttons row */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-6" id="product-category-filters">
            {[
              { id: 'all', label: 'كافّة القطع الجلدية' },
              { id: 'wallets', label: 'مَحافِظ متميزة' },
              { id: 'bags', label: 'حقائب أعمال وسفَر' },
              { id: 'accessories', label: 'إكسسوارات ومفكرات' },
              { id: 'boxes', label: 'علب ملكيّة للساعات' }
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all duration-300 ${
                  selectedCategory === cat.id
                    ? 'bg-stone-950 text-[#faf9f5] dark:bg-stone-100 dark:text-stone-950 shadow-md ring-2 ring-[#c5a059]/40'
                    : 'bg-stone-100 dark:bg-stone-900/60 text-stone-600 dark:text-stone-400 border border-stone-200/50 dark:border-stone-800/80 hover:bg-stone-200 dark:hover:bg-stone-900'
                }`}
                id={`filter-btn-${cat.id}`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8" id="products-catalog-grid">
          <AnimatePresence mode="popLayout">
            {filteredProducts.map((product) => (
              <motion.div
                key={product.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="group relative flex flex-col h-full rounded-2xl bg-white dark:bg-[#12131a] border border-stone-200/60 dark:border-stone-900/80 overflow-hidden shadow-md hover:shadow-xl hover:border-[#c5a059]/40 transition-all duration-300 transform md:hover:-translate-y-1"
                id={`product-card-${product.id}`}
              >
                {/* Card Tag Badge (e.g. Best seller) */}
                {product.badge && (
                  <div className="absolute top-4 right-4 z-20 bg-stone-950/90 dark:bg-stone-100/95 text-stone-50 dark:text-stone-950 text-[9px] font-black tracking-widest px-3 py-1 rounded-full uppercase border border-[#c5a059]/30 shadow-md">
                    {product.badge}
                  </div>
                )}

                {/* Elegant product rating top indicators */}
                <div className="absolute top-4 left-4 z-20 flex items-center gap-1 bg-stone-950/70 backdrop-blur-md px-2.5 py-1 rounded-lg text-[#c5a059] text-[10px] font-semibold">
                  <Star className="w-3.5 h-3.5 fill-[#c5a059]" />
                  <span>{product.rating}</span>
                </div>

                {/* Product Image Frame */}
                <div className="relative aspect-[4/3] bg-stone-100 dark:bg-stone-900 overflow-hidden cursor-pointer" onClick={() => openProductModal(product)}>
                  <img
                    src={product.images[0]}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 ease-out brightness-[0.93] group-hover:brightness-100"
                  />
                  {/* Hover Quick view Indicator overlay */}
                  <div className="absolute inset-0 bg-stone-950/40 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <span className="px-5 py-2.5 bg-[#eae9e6] text-stone-950 text-xs font-bold rounded-lg shadow-2xl flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition-all">
                      <Layers className="w-3.5 h-3.5" /> نظرة فاحصة وتخصيص
                    </span>
                  </div>
                </div>

                {/* Product Copy Details Block */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4 text-right">
                  <div className="space-y-2">
                    {/* Category Label */}
                    <span className="text-[10px] font-semibold text-[#c5a059] uppercase tracking-wider block">
                      {product.category === 'wallets' ? 'محافظ جلدية نباتية' : 
                       product.category === 'bags' ? 'حقيبة ترحال وأعمال' : 
                       product.category === 'accessories' ? 'إكسسوار فريد الطراز' : 'علب التتويج والحفظ'}
                    </span>

                    {/* Arabic Master Name */}
                    <h4 
                      onClick={() => openProductModal(product)} 
                      className="text-base md:text-lg font-bold text-stone-950 dark:text-stone-50 hover:text-[#c5a059] transition-colors cursor-pointer leading-tight line-clamp-1"
                    >
                      {product.name}
                    </h4>

                    {/* Product English Name */}
                    <p className="text-[10px] font-mono text-stone-400 tracking-wider">
                      {product.nameEn}
                    </p>

                    {/* Brief description */}
                    <p className="text-xs text-stone-500 dark:text-stone-400 line-clamp-2 leading-relaxed">
                      {product.description}
                    </p>
                  </div>

                  {/* Pricing and Action trigger bar */}
                  <div className="space-y-4 pt-2">
                    
                    {/* Price and color bullets */}
                    <div className="flex items-center justify-between">
                      {/* Interactive visual available color bullets */}
                      <div className="flex -space-x-1 border-r border-stone-200/50 dark:border-stone-800 pr-3">
                        {product.colors.map(col => (
                          <span 
                            key={col.name} 
                            style={{ backgroundColor: col.hex }} 
                            className="w-3 h-3 rounded-full border border-stone-50 dark:border-stone-900 shadow-xs" 
                            title={col.nameAr}
                          />
                        ))}
                      </div>

                      {/* Majestic visual price box */}
                      <div className="text-right">
                        <span className="text-xs text-stone-400 dark:text-stone-500 block leading-none">صناعة مخصصة</span>
                        <p className="text-base md:text-lg font-bold text-[#c5a059] tracking-tight mt-1">
                          {formatPrice(product.priceYer)}
                        </p>
                      </div>
                    </div>

                    {/* Card Actions Container */}
                    <div className="grid grid-cols-2 gap-2 pt-1 font-bold">
                      {/* Detailed Config Trigger */}
                      <button
                        onClick={() => openProductModal(product)}
                        className="py-2.5 px-3 border border-stone-300 dark:border-stone-800 rounded-lg text-xs hover:border-stone-400 dark:hover:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-900 text-stone-700 dark:text-stone-300 transition-all duration-200"
                        id={`details-btn-${product.id}`}
                      >
                        تخصيص كامل
                      </button>

                      {/* Smart Cart Add button */}
                      <button
                        onClick={() => addToCart(product, product.colors[0].nameAr, '', false)}
                        className="py-2.5 px-3 bg-[#c5a059] hover:bg-[#b08c47] text-stone-950 rounded-lg text-xs transition-colors duration-200 flex items-center justify-center gap-1"
                        id={`addcur-btn-${product.id}`}
                      >
                        <ShoppingCart className="w-3.5 h-3.5 shrink-0" />
                        أضف للسلة
                      </button>
                    </div>

                    {/* Instant click to WhatsApp block */}
                    <button
                      onClick={() => sendInstantWhatsAppOrder(product, product.colors[0].nameAr, '')}
                      className="w-full py-2 bg-green-500/10 hover:bg-green-500/15 border border-green-500/20 hover:border-green-500/30 text-green-600 dark:text-green-400 rounded-lg text-xs transition-all duration-200 flex items-center justify-center gap-1.5"
                      id={`instant-wa-btn-${product.id}`}
                    >
                      <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                      شراء عبر واتساب مباشرة
                    </button>

                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </section>

      {/* 7. Detailed Product Customization Modal Overlay */}
      <AnimatePresence>
        {selectedProduct && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6 lg:p-10 text-right font-sans">
            {/* Modal Backdrop overlay shadow */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProduct(null)}
              className="fixed inset-0 bg-stone-950/85 backdrop-blur-md"
            ></motion.div>

            {/* Modal main content Container box */}
            <motion.div
              initial={{ scale: 0.95, y: 30, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 20, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="relative w-full max-w-5xl rounded-2xl bg-white dark:bg-[#12131a] border border-stone-200 dark:border-stone-900 shadow-2xl overflow-hidden z-10 grid grid-cols-1 lg:grid-cols-12 max-h-[90vh] lg:max-h-none overflow-y-auto"
              id="details-modal-box"
            >
              {/* Close Button top-left corner */}
              <button
                onClick={() => setSelectedProduct(null)}
                className="absolute top-4 left-4 z-30 p-2.5 rounded-full bg-stone-900/60 hover:bg-stone-900/80 text-white border border-stone-700/80 transition-colors"
                id="modal-close-btn"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Column 1: Image sliders & Specifications [LHS - 5 spans] */}
              <div className="lg:col-span-5 bg-stone-50 dark:bg-stone-950/60 p-6 flex flex-col justify-between border-l border-stone-200 dark:border-stone-900 relative">
                <div className="space-y-6">
                  
                  {/* Main Display Image */}
                  <div className="relative aspect-[4/3] rounded-xl overflow-hidden shadow-md border dark:border-stone-900 bg-stone-800">
                    <img 
                      src={selectedProduct.images[modalImageIndex]} 
                      alt={selectedProduct.name}
                      className="w-full h-full object-cover duration-300 brightness-95" 
                    />
                    
                    {/* Tiny badges overlay */}
                    {selectedProduct.badge && (
                      <span className="absolute bottom-4 right-4 bg-[#c5a059] text-stone-950 px-3 py-1 text-[9px] font-black rounded-md shadow-lg">
                        {selectedProduct.badge}
                      </span>
                    )}
                  </div>

                  {/* Thumbnail Selector list */}
                  <div className="flex gap-2 justify-center">
                    {selectedProduct.images.map((imgUrl, idx) => (
                      <button
                        key={idx}
                        onClick={() => setModalImageIndex(idx)}
                        className={`w-16 h-12 rounded-lg overflow-hidden border-2 transition-all ${
                          modalImageIndex === idx ? 'border-[#c5a059] scale-105' : 'border-transparent opacity-60 hover:opacity-100'
                        }`}
                        id={`modal-thumb-${idx}`}
                      >
                        <img src={imgUrl} alt="تفصيل يدوي" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>

                  {/* Detailed Spec Bullet items */}
                  <div className="space-y-4 pt-4 border-t border-stone-200 dark:border-stone-900 text-stone-600 dark:text-stone-300">
                    
                    <div className="flex items-start gap-2 text-xs">
                      <Briefcase className="w-4 h-4 text-[#c5a059] mt-0.5 shrink-0" />
                      <div>
                        <span className="font-bold block text-stone-900 dark:text-white">جودة الخامات الجلدية:</span>
                        <span className="text-stone-500 dark:text-stone-400">{selectedProduct.leatherType}</span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 text-xs">
                      <Layers className="w-4 h-4 text-[#c5a059] mt-0.5 shrink-0" />
                      <div>
                        <span className="font-bold block text-stone-900 dark:text-white">الأبعاد والتحجيم القياسي:</span>
                        <span className="text-stone-500 dark:text-stone-400">{selectedProduct.dimensions}</span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 text-xs">
                      <Clock className="w-4 h-4 text-[#c5a059] mt-0.5 shrink-0" />
                      <div>
                        <span className="font-bold block text-stone-900 dark:text-white">طوق التحضير والصناعة اليدوية:</span>
                        <span className="text-[#c5a059]">{selectedProduct.craftingTime}</span>
                      </div>
                    </div>

                  </div>
                </div>

                {/* Secure shipping claim footnote */}
                <div className="pt-6 mt-6 border-t border-stone-200 dark:border-[#1c1d24] text-center text-[10px] text-stone-400 dark:text-stone-500 flex items-center justify-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-green-500" />
                  <span>دعامة حماية ضد عوارض الشحن والارتجاع</span>
                </div>
              </div>


              {/* Column 2: Personalization & Interactive checkout selectors [RHS - 7 spans] */}
              <div className="lg:col-span-7 p-6 md:p-8 space-y-6 flex flex-col justify-between">
                <div className="space-y-5">
                  
                  {/* Category and English visual reference */}
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-[#c5a059] tracking-widest uppercase">
                      منتجات HESHAM الأصلية
                    </span>
                    <span className="text-xs font-mono text-stone-400 bg-stone-100 dark:bg-stone-900 px-2 py-0.5 rounded">
                      ID: {selectedProduct.id}
                    </span>
                  </div>

                  {/* Product title headings */}
                  <div className="space-y-1">
                    <h3 className="text-2xl md:text-3xl font-extrabold text-stone-900 dark:text-white">
                      {selectedProduct.name}
                    </h3>
                    <p className="text-xs font-serif italic text-stone-400 text-glow">
                      {selectedProduct.nameEn}
                    </p>
                  </div>

                  {/* Rating / Review count box */}
                  <div className="flex items-center gap-1 justify-end text-xs text-stone-500 dark:text-stone-400">
                    <span className="text-stone-400 dark:text-stone-500">({selectedProduct.reviewsCount} تقييم فائق)</span>
                    <span className="font-bold text-stone-800 dark:text-stone-200 mr-2">{selectedProduct.rating} / 5.0</span>
                    <div className="flex text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-[#c5a059] text-[#c5a059]" />
                      ))}
                    </div>
                  </div>

                  {/* Visual Price Showcase Box */}
                  <div className="p-4 rounded-xl bg-stone-100 dark:bg-stone-950 border border-stone-300/40 dark:border-stone-800 flex justify-between items-center">
                    <span className="text-xs text-stone-500 dark:text-stone-400 font-bold">قيمة المشغل (شامل الضريبة والنقش)</span>
                    <span className="text-2xl font-black text-[#c5a059]">
                      {formatPrice(selectedProduct.priceYer)}
                    </span>
                  </div>

                  {/* In-depth descriptions */}
                  <p className="text-sm text-stone-600 dark:text-stone-300 leading-relaxed font-light">
                    {selectedProduct.detailedDescription}
                  </p>

                  <hr className="border-stone-200 dark:border-stone-900" />

                  {/* Core Customizer form elements */}
                  <div className="space-y-4">
                    
                    {/* Shadow Selector (Colors) */}
                    <div>
                      <span className="text-xs font-bold text-stone-800 dark:text-stone-200 block mb-2">
                        ١. اختر كود ولون الجلد المعتمد: <span className="text-[#c5a059]">({selectedColor})</span>
                      </span>
                      <div className="flex flex-wrap gap-2.5">
                        {selectedProduct.colors.map(col => {
                          const isActive = selectedColor === col.nameAr;
                          return (
                            <button
                              key={col.name}
                              onClick={() => setSelectedColor(col.nameAr)}
                              className={`px-3 py-2 rounded-lg border-2 text-xs font-bold transition-all flex items-center gap-2 ${
                                isActive 
                                  ? 'border-[#c5a059] bg-[#c5a059]/5 text-[#c5a059]' 
                                  : 'border-stone-300 dark:border-stone-800 text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900'
                              }`}
                              id={`color-btn-${col.name}`}
                            >
                              <span style={{ backgroundColor: col.hex }} className="w-3.5 h-3.5 rounded-full border border-stone-400" />
                              {col.nameAr}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Free Laser personalization customization field */}
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-bold text-stone-800 dark:text-stone-200 flex items-center gap-1 leading-none">
                          <Check className="w-3.5 h-3.5 text-green-500" /> ٢. الحفر الحراري وحفر الأسماء (مجاني)
                        </span>
                        <span className="text-[10px] text-green-500 font-bold bg-green-500/10 px-2 py-0.5 rounded">اختياري</span>
                      </div>
                      <input 
                        type="text" 
                        value={customEngraving}
                        onChange={(e) => setCustomEngraving(e.target.value)}
                        placeholder="على سبيل المثال: HESHAM / هشام 1990"
                        className="w-full px-4 py-3 text-sm bg-stone-100 dark:bg-stone-950 border border-stone-300 dark:border-stone-800 rounded-xl outline-none focus:ring-2 focus:ring-[#c5a059]/30 text-stone-900 dark:text-[#faf9f5]"
                        maxLength={40}
                        id="laser-engraving-input"
                      />
                      <p className="text-[10px] text-stone-400 mt-1.5 leading-relaxed">
                        * يوصى بلغة الحروف أو التموجات الإنجليزية أو العربية لروعة الشكل النهائي. حفر دقيق باستخدام حفر الضغط الساخن بنبرة ملكية مأثورة.
                      </p>
                    </div>

                  </div>

                </div>

                {/* Form controls/Add actions */}
                <div className="pt-6 border-t border-stone-200 dark:border-stone-900 space-y-3">
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-semibold">
                    {/* Add to VIP Cart */}
                    <button
                      onClick={() => {
                        addToCart(selectedProduct, selectedColor, customEngraving, false);
                        setSelectedProduct(null);
                      }}
                      className="w-full py-4 px-6 bg-stone-100 highlight-gold hover:bg-stone-200 text-stone-900 dark:bg-stone-900 dark:text-stone-100 dark:hover:bg-stone-800 rounded-xl text-xs tracking-wider transition-all duration-200 flex items-center justify-center gap-2 border border-stone-300/40 dark:border-stone-800"
                      id="modal-add-to-cart-btn"
                    >
                      <ShoppingCart className="w-4 h-4 shrink-0 text-[#c5a059]" />
                      إرسال وتثبيت في السلة الفاخرة
                    </button>

                    {/* Instant checkout on whatsapp */}
                    <button
                      onClick={() => {
                        sendInstantWhatsAppOrder(selectedProduct, selectedColor, customEngraving);
                      }}
                      className="w-full py-4 px-6 bg-[#c5a059] hover:bg-[#b08c47] text-stone-950 rounded-xl text-xs tracking-wider transition-all duration-200 flex items-center justify-center gap-2"
                      id="modal-instant-wa-btn"
                    >
                      <MessageCircle className="w-4 h-4 shrink-0" />
                      شراء عبر واتساب الآن
                    </button>
                  </div>

                  <p className="text-[11px] text-center text-stone-500 dark:text-stone-400">
                    * عند اختيار شراء عبر الواتساب سيتم تحويلك برسمة طلبك مع مواصفات لون الجلد وتخصيص الاسم وتفاصيل السعر فوراً.
                  </p>

                </div>

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 8. Breathtaking Custom Orders & Bespoke Configurator */}
      <section className="py-20 bg-stone-100 dark:bg-stone-950/40 border-t border-b border-stone-200/50 dark:border-stone-900/60" id="bespoke-studio">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          
          <div className="text-center space-y-4 mb-12">
            <div className="inline-flex w-12 h-12 rounded-full bg-[#c5a059]/10 text-[#c5a059] items-center justify-center border border-[#c5a059]/30">
              <Sparkles className="w-6 h-6 animate-spin" style={{ animationDuration: '6s' }} />
            </div>
            <h3 className="text-2.5xl md:text-3.5xl font-serif text-stone-950 dark:text-white font-extrabold tracking-tight">
              صالون HESHAM للتصاميم والطلبات الفردية المخصصة
            </h3>
            <p className="text-sm md:text-base text-stone-500 dark:text-stone-400 max-w-xl mx-auto">
              ألا تجد مبتغاك في كتالوج العرض؟ يوفر مشغلنا خدمة تفصيل أي قطعة مصنوعات جلدية تحكّمية ترغب بها. صمّم أبعادها وخلفياتها واجعل صناعتنا اليدوية تحكي ذوقك.
            </p>
          </div>

          {/* Form container */}
          <div className="bg-white dark:bg-[#12131a] rounded-2.5xl p-6 sm:p-10 border border-stone-200 dark:border-stone-900 shadow-2xl relative overflow-hidden" id="custom-bespoke-form-container">
            <div className="absolute top-0 right-0 w-24 h-24 bg-[#c5a059]/5 rounded-bl-full pointer-events-none"></div>

            <form onSubmit={sendCustomOrderWhatsApp} className="space-y-6 text-right font-medium">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                
                {/* Client Name input */}
                <div>
                  <label className="text-xs font-bold text-stone-700 dark:text-stone-300 block mb-2">
                    اسمكم الكريم المحترم *
                  </label>
                  <input
                    type="text"
                    required
                    value={customOrder.clientName}
                    onChange={(e) => setCustomOrder({ ...customOrder, clientName: e.target.value })}
                    placeholder="مثال: المهندس هشام أحمد"
                    className="w-full px-4 py-3 text-sm bg-stone-50 dark:bg-stone-950 border border-stone-300 dark:border-stone-850 rounded-xl outline-none focus:ring-2 focus:ring-[#c5a059]/30 text-stone-900 dark:text-stone-100"
                    id="custom-name-field"
                  />
                </div>

                {/* Accessory type drop list */}
                <div>
                  <label className="text-xs font-bold text-stone-700 dark:text-stone-300 block mb-2">
                    نوع وتحجيم المشغولات الفاخرة المطلوبة *
                  </label>
                  <select
                    value={customOrder.accessoryType}
                    onChange={(e) => setCustomOrder({ ...customOrder, accessoryType: e.target.value })}
                    className="w-full px-4 py-3 text-sm bg-stone-50 dark:bg-stone-950 border border-stone-300 dark:border-stone-850 rounded-xl outline-none focus:ring-2 focus:ring-[#c5a059]/30 text-stone-900 dark:text-stone-100"
                    id="custom-type-field"
                  >
                    <option value="محفظة كلاسيكية سميكة يدوياً">محفظة كلاسيكية سميكة يدوياً</option>
                    <option value="حقيبة لاب توب بجيوب إضافية">حقيبة لاب توب بجيوب إضافية</option>
                    <option value="حزام عريض خاص ومبكل نحاس">حزام عريض خاص ومبكل نحاس</option>
                    <option value="علبة للساعات والنظارات الثمينة">علبة للساعات والنظارات الثمينة</option>
                    <option value="غلاف مفكرة جلدية متينة برباط مغناطيسي">غلاف مفكرة جلدية متينة برباط مغناطيسي</option>
                    <option value="جراب نظارة / جراب مخصص للمصحف الشريف">جراب نظارة / جراب مخصص للمصحف الشريف</option>
                    <option value="حقيبة سفر و عطلات فلكية الحجم">حقيبة سفر و عطلات فلكية الحجم</option>
                    <option value="قطعة جلدية مخصصة ومبتكرة (أخرى)">قطعة جلدية مخصصة ومبتكرة (أخرى)</option>
                  </select>
                </div>

              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                
                {/* Custom leather color preference input button */}
                <div>
                  <label className="text-xs font-bold text-stone-700 dark:text-stone-300 block mb-2">
                    لون الجلد المطلوب
                  </label>
                  <select
                    value={customOrder.leatherColor}
                    onChange={(e) => setCustomOrder({ ...customOrder, leatherColor: e.target.value })}
                    className="w-full px-4 py-3 text-sm bg-stone-50 dark:bg-stone-950 border border-stone-300 dark:border-stone-850 rounded-xl outline-none focus:ring-2 focus:ring-[#c5a059]/30 text-[#242320] dark:text-[#eae9e6]"
                    id="custom-color-field"
                  >
                    <option value="هافان / بني عسلي">هافان / بني عسلي (Tan Honey)</option>
                    <option value="أسود غامق قاتم وملكي">أسود غامق قاتم وملكي (Majestic Black)</option>
                    <option value="بني بني غامق مستشرق">بني غامق شوكولا (Dark Mahogany)</option>
                    <option value="أخضر غابات زجاجي فاخر">أخضر غابات عشب كلاسيكي (Imperial Green)</option>
                    <option value="أزرق ليلي ملكي داكن">كحلي ليلي دجلي (Midnight Ducal Blue)</option>
                  </select>
                </div>

                {/* Personalization initials for free */}
                <div>
                  <label className="text-xs font-bold text-stone-700 dark:text-stone-300 block mb-2">
                    الاسم أو الرمز المطلوب حفرة بالحرارة
                  </label>
                  <input
                    type="text"
                    value={customOrder.engravingText}
                    onChange={(e) => setCustomOrder({ ...customOrder, engravingText: e.target.value })}
                    placeholder="مثال: HESH_AM_90"
                    className="w-full px-4 py-3 text-sm bg-stone-50 dark:bg-stone-950 border border-stone-300 dark:border-stone-850 rounded-xl outline-none focus:ring-2 focus:ring-[#c5a059]/30 text-stone-900 dark:text-stone-100"
                    maxLength={30}
                    id="custom-engraving-field"
                  />
                </div>

              </div>

              {/* In-depth details description request */}
              <div>
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300 block mb-2">
                  شرح ومواصفات تفصيلية للقطعة (المقاسات المحددة، الجيوب، التفاصيل الخاصة) *
                </label>
                <textarea
                  required
                  rows={4}
                  value={customOrder.details}
                  onChange={(e) => setCustomOrder({ ...customOrder, details: e.target.value })}
                  placeholder="رجاءً اكتب مقاساتك بدقة، أو أي متطلبات إضافية كنوع الفواصل أو نوع الأجهزة وحاويات الحاسوب، والمنافع التي ترغب بربطها في جلد الصناعة..."
                  className="w-full px-4 py-3 text-sm bg-stone-50 dark:bg-stone-950 border border-stone-300 dark:border-stone-850 rounded-xl outline-none focus:ring-2 focus:ring-[#c5a059]/30 text-stone-900 dark:text-stone-100 resize-none"
                  id="custom-details-field"
                ></textarea>
              </div>

              {/* Production schedule priority / urgency level selector */}
              <div>
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300 block mb-2">
                  أولوية الصياغة والصنع اليدوي
                </label>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { id: 'normal', text: 'صياغة عادية برواق (فترة قياسية)', desc: 'بثقة تامة وبصنع يدوي متقن ومتأني' },
                    { id: 'express', text: 'صناعة مستعجلة للمناسبة والهدية', desc: 'أولوية قصوى لمصنعنا مع علبة إهداء فاخرة' }
                  ].map(urge => (
                    <button
                      key={urge.id}
                      type="button"
                      onClick={() => setCustomOrder({ ...customOrder, urgency: urge.id as 'normal' | 'express' })}
                      className={`p-4 rounded-xl border-2 text-right transition-all duration-200 ${
                        customOrder.urgency === urge.id
                          ? 'border-[#c5a059] bg-[#c5a059]/5'
                          : 'border-stone-300 dark:border-stone-800 text-stone-600 dark:text-stone-400'
                      }`}
                      id={`custom-urgency-btn-${urge.id}`}
                    >
                      <span className="text-xs font-bold text-stone-900 dark:text-stone-100 block">{urge.text}</span>
                      <span className="text-[10px] text-stone-400 mt-1 block">{urge.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Submit CTA button */}
              <div className="pt-4 flex flex-col items-center justify-center space-y-4">
                <button
                  type="submit"
                  className="px-10 py-4.5 bg-stone-950 dark:bg-stone-100 text-white dark:text-stone-950 text-sm font-bold tracking-wider rounded-xl transition-all duration-300 flex items-center justify-center gap-2 hover:scale-[1.03] shadow-xl w-full sm:w-auto"
                  id="submit-bespoke-form-btn"
                >
                  <MessageCircle className="w-5 h-5 shrink-0" />
                  إرسال مواصفات الطلب إلى واتساب المتجر
                </button>
                <p className="text-[10px] text-stone-400 dark:text-stone-500 leading-relaxed text-center max-w-md">
                  * سيتم توليد وتجميع مواصفات الكبس المطبوعة أعلاه وتحويلك لمحادثة الوتساب برقم 780066128 للمباشرة ومراجعة السعر الإجمالي وموعد التسليم.
                </p>
              </div>

            </form>

            {customOrderSubmitted && (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                className="absolute inset-0 bg-stone-950/90 flex flex-col items-center justify-center text-center p-6 space-y-4"
                id="bespoke-thanks-overlay"
              >
                <div className="w-16 h-16 bg-green-500/10 text-green-400 rounded-full flex items-center justify-center border border-green-500/30">
                  <Check className="w-10 h-10" />
                </div>
                <h4 className="text-xl font-bold text-white">تم تحويل تفاصيلك لطلبات الوتساب الفورية</h4>
                <p className="text-stone-400 text-xs max-w-sm">
                  إذا لم يعمل المحول التلقائي، يمكنك إعادة إرساله بالنقر على الزر للمراسلة وإبلاعنا بالاسم الشخصي.
                </p>
                <button 
                  onClick={() => setCustomOrderSubmitted(false)}
                  className="px-5 py-2.5 bg-stone-800 text-stone-100 text-xs font-semibold rounded-lg hover:bg-stone-750 transition-colors"
                >
                  صياغة طلب مخصص جديد
                </button>
              </motion.div>
            )}

          </div>

        </div>
      </section>

      {/* 9. Interactive Shopping Cart Drawer Panel */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden font-sans">
            {/* Backdrop slide shadowing */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="absolute inset-0 bg-stone-950/80 backdrop-blur-xs"
            ></motion.div>

            {/* Sliding Panel container */}
            <div className="absolute inset-y-0 left-0 max-w-full flex pl-0 text-right">
              <motion.div
                initial={{ x: '-100%' }}
                animate={{ x: 0 }}
                exit={{ x: '-100%' }}
                transition={{ type: "tween", duration: 0.35, ease: "easeOut" }}
                className="w-screen max-w-md bg-[#faf9f5] dark:bg-[#0e0f14] border-r border-stone-200 dark:border-stone-900 shadow-2xl flex flex-col justify-between"
                id="cart-drawer-panel"
              >
                {/* Header panel */}
                <div className="p-6 border-b border-stone-200 dark:border-stone-900 bg-stone-100/40 dark:bg-stone-950/40 flex items-center justify-between">
                  {/* Close button */}
                  <button 
                    onClick={() => setIsCartOpen(false)}
                    className="p-2 rounded-lg text-stone-500 hover:text-stone-800 dark:hover:text-stone-100 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>

                  <div className="flex items-center gap-2">
                    <span className="text-xs bg-amber-500/10 text-[#c5a059] px-2.5 py-1 rounded-full font-bold">
                      {getCartItemCount()} قطعة
                    </span>
                    <h3 className="text-lg font-extrabold text-stone-900 dark:text-white flex items-center gap-1.5 leading-none">
                      سلتك الفاخرة <ShoppingCart className="w-5 h-5 text-[#c5a059]" />
                    </h3>
                  </div>
                </div>

                {/* Main Body List scroll panel */}
                <div className="flex-1 p-6 overflow-y-auto space-y-4" id="cart-items-list-container">
                  {cart.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center space-y-4 text-[#bfbbb4]">
                      <div className="w-16 h-16 rounded-full bg-stone-100 dark:bg-stone-950/80 flex items-center justify-center text-stone-400 border border-stone-200 dark:border-stone-900">
                        <ShoppingBag className="w-8 h-8" />
                      </div>
                      <p className="text-sm font-semibold max-w-xs text-center leading-relaxed">
                        سلّة المشتريات خالية من القطع الجلدية حالياً. تجول برواق في كتالوج المعرض وأضف ما ترغب في اقتنائه.
                      </p>
                      <button
                        onClick={() => setIsCartOpen(false)}
                        className="px-5 py-2.5 bg-[#c5a059] text-stone-950 text-xs font-bold rounded-lg hover:bg-[#b08c47] transition-all"
                      >
                        تصفح كتالوج المتجر
                      </button>
                    </div>
                  ) : (
                    cart.map((item, index) => (
                      <div 
                        key={index} 
                        className="p-3 rounded-xl bg-white dark:bg-[#12131a] border border-stone-200/60 dark:border-stone-900 flex gap-3 text-right"
                        id={`cart-item-row-${index}`}
                      >
                        {/* Mini image thumbnail */}
                        <div className="w-20 h-20 rounded-lg overflow-hidden shrink-0 border dark:border-stone-850">
                          <img src={item.product.images[0]} alt={item.product.name} className="w-full h-full object-cover" />
                        </div>

                        {/* Text settings details */}
                        <div className="flex-1 flex flex-col justify-between">
                          <div className="space-y-1">
                            <h4 className="text-xs font-bold text-stone-900 dark:text-white text-ellipsis overflow-hidden line-clamp-1">{item.product.name}</h4>
                            <div className="flex flex-wrap items-center justify-end gap-x-2 gap-y-0.5 text-[10px] text-stone-400">
                              {item.customEngraving && (
                                <span className="bg-amber-500/5 text-[#c5a059] border border-amber-500/10 px-1.5 rounded">نقش: {item.customEngraving}</span>
                              )}
                              <span className="bg-stone-100 dark:bg-stone-900 px-1.5 rounded">الجلد: {item.selectedColor}</span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-stone-200/50 dark:border-stone-900">
                            
                            {/* Trash remove index action */}
                            <button
                              onClick={() => {
                                const updated = [...cart];
                                updated.splice(index, 1);
                                setCart(updated);
                                triggerToast('تمت إزالة عنصر من السلة');
                              }}
                              className="text-[10px] font-bold text-red-500 hover:text-red-400 cursor-pointer"
                            >
                              إزالة عنصر
                            </button>

                            {/* Quantity toggles controller */}
                            <div className="flex items-center gap-2 bg-stone-100 dark:bg-stone-950 px-2 py-1 rounded-lg border dark:border-stone-850" id={`quantity-panel-${index}`}>
                              <button 
                                onClick={() => updateQuantity(index, 1)}
                                className="p-1 rounded text-stone-750 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-900 duration-150"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                              <span className="text-xs font-mono font-bold text-stone-900 dark:text-stone-100 w-4 text-center">{item.quantity}</span>
                              <button 
                                onClick={() => updateQuantity(index, -1)}
                                className="p-1 rounded text-stone-750 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-900 duration-150"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                            </div>

                            {/* Price times count */}
                            <span className="text-xs font-bold text-[#c5a059] font-mono">
                              {formatPrice(item.product.priceYer * item.quantity)}
                            </span>

                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Footer panel - billing summaries and checkout button details */}
                {cart.length > 0 && (
                  <div className="p-6 border-t border-stone-200 dark:border-stone-900 bg-stone-100/40 dark:bg-stone-950/40 space-y-4">
                    
                    {/* Bill specs rows */}
                    <div className="space-y-2 text-xs font-bold text-stone-600 dark:text-stone-400">
                      
                      <div className="flex justify-between items-center">
                        <span className="font-mono text-stone-900 dark:text-white">{getCartItemCount()} قطعة</span>
                        <span>عدد القطع المحددة:</span>
                      </div>

                      <div className="flex justify-between items-center text-green-500 text-[11px] bg-green-500/10 p-2 rounded-lg">
                        <span>خيار معتمد بالكامل</span>
                        <span>نقش ليزري وتعبئة فاخرة:</span>
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t border-stone-300 dark:border-stone-850 text-base font-extrabold text-[#c5a059]">
                        <span className="font-mono">{formatPrice(getCartTotal())}</span>
                        <span className="text-stone-900 dark:text-white">المجموع الإجمالي:</span>
                      </div>

                    </div>

                    {/* Submit Whatsapp Checkout */}
                    <button
                      onClick={sendCartWhatsAppOrder}
                      className="w-full py-4 bg-[#c5a059] hover:bg-[#b08c47] text-stone-950 font-extrabold text-xs tracking-widest uppercase rounded-xl shadow-xl transition-all duration-300 flex items-center justify-center gap-2 group scale-100 hover:scale-[1.02] active:scale-95"
                      id="cart-submit-order-whatsapp-btn"
                    >
                      <MessageCircle className="w-5 h-5 shrink-0" />
                      إرسال الطلبيّة كاملة لواتساب المتجر
                    </button>

                    <p className="text-[10px] text-center text-stone-400 dark:text-stone-500 leading-relaxed">
                      * التوصيل شامل العلبة الفاخرة المبطنة ومغلفة بحماية ممتازة. عند إرسال الطلبية سيتم فتح واتساب المتجر وإدراج كافة البيانات بسرد مرتب ومتقن تلقائياً.
                    </p>

                  </div>
                )}

              </motion.div>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* 10. Heritage / Designer Journey Section */}
      <section className="py-20 bg-[#faf9f5] dark:bg-[#090a0d] border-t border-stone-200/40 dark:border-stone-900" id="artist-heritage">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Right container: Image of workshop */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] border-2 border-[#c5a059]/30 shadow-2xl bg-stone-950">
                <img 
                  src="https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=800" 
                  alt="مشغل هشام لصقل الجلود اليدوية" 
                  className="w-full h-full object-cover opacity-85 brightness-95"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/50 to-transparent"></div>
              </div>
              {/* Overlay quote box */}
              <div className="absolute -bottom-6 -left-4 sm:left-6 p-4 rounded-xl bg-white dark:bg-[#12131a] border border-stone-200 dark:border-stone-900 shadow-xl max-w-xs text-right">
                <p className="text-xs italic text-stone-500 dark:text-stone-400">
                  "التفاصيل الصغيرة الدقيقة والمحفورة بحكمة هي خط الفارق بين المشغولات العابرة والتحف الأجنبية التي تنتقل عبر العصور."
                </p>
                <span className="block text-xs font-bold text-[#c5a059] mt-2 leading-none">— هشام، رئيس الحرفيين بمشغلات HESHAM</span>
              </div>
            </div>

            {/* Left: textual representation */}
            <div className="lg:col-span-7 space-y-6 text-right">
              <span className="text-xs font-serif uppercase tracking-[0.35em] text-[#c5a059] font-bold block">Heritage Craft</span>
              <h3 className="text-2.5xl md:text-3.5xl font-serif font-black text-stone-900 dark:text-stone-100">
                قصّتنا ودباغتنا اليدوية الشامخة
              </h3>
              <p className="text-sm md:text-base text-stone-600 dark:text-stone-300 leading-relaxed font-light">
                بدأت مشغلات <span className="font-bold text-stone-900 dark:text-white">هِشام HESHAM للجلود الفاخرة</span> كشغف موروث يهدف لإعادة هيبة الصناعات اليدوية في زمن السرعة والاستهلاك الفاني. نحن لا نصنع أشكالاً بل نصقل وقاراً. نختار خاماتنا بمستويات غربلة قاسية من مدابغ معتمدة دولياً في إيطاليا وإسبانيا، ونثري تفاصيلها محلياً بالنقش والكبس المتقن لتخرج كل حقيبة أو محفظة كرمز يعكس هويتكم المرموقة.
              </p>
              
              <div className="flex gap-6 justify-end items-center text-xs pt-4 text-stone-500 dark:text-stone-400 font-bold">
                <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-[#c5a059]" /> خط خياطة مزدوج يدوي متين</span>
                <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-[#c5a059]" /> إبزيم معدني مصمت فائر الصفائح</span>
                <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-[#c5a059]" /> خشب بقواعد مضاعفة</span>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 11. Immersive Royal Footer */}
      <footer className="bg-stone-950 text-stone-400 pt-16 pb-8 border-t border-stone-900 text-right">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 pb-12 border-b border-stone-900">
          
          {/* Brand section [Spans 5] */}
          <div className="lg:col-span-5 space-y-4">
            <h4 className="text-2.5xl font-serif text-white tracking-[0.25em] font-black">HESHAM</h4>
            <div className="flex items-center gap-2 justify-end">
              <p className="text-[10px] tracking-widest text-[#c5a059] uppercase font-bold">THE HIGHEST SYMBOL OF MAJESTY</p>
              <div className="w-8 h-[1px] bg-[#c5a059]"></div>
            </div>
            <p className="text-xs text-stone-500 leading-relaxed max-w-sm ml-auto">
              متجرنا مسكوب بصياغة بريميوم وحصرية، يقدم لكم تشكيلات المصنوعات الجلدية يدوية الصنع المتقنة والمتاحة للشحن السريع والآمن إلى كافة أنحاء الجمهورية والمدن الرئيسية.
            </p>
            {/* Quick WhatsApp Support contact details */}
            <div className="pt-4 flex items-center justify-end gap-3">
              <div className="text-right">
                <span className="text-[10px] text-stone-500 block leading-tight">للدعم المباشر ومكالمات الأعمال</span>
                <a href="https://wa.me/967780066128" className="text-sm text-stone-200 hover:text-[#c5a059] font-mono font-bold leading-normal">
                  +967 780066128
                </a>
              </div>
              <div className="w-10 h-10 rounded-xl bg-green-500/10 text-green-400 flex items-center justify-center border border-green-500/20">
                <MessageCircle className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* Quick Category link links [Spans 3] */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-xs font-serif uppercase tracking-widest text-white font-bold text-glow">المجموعات والكتالوج</h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#collection-gallery" onClick={() => setSelectedCategory('all')} className="hover:text-[#c5a059] transition-colors">كافة المصنوعات</a></li>
              <li><a href="#collection-gallery" onClick={() => setSelectedCategory('wallets')} className="hover:text-[#c5a059] transition-colors">محافِظ هِشام الفخمة</a></li>
              <li><a href="#collection-gallery" onClick={() => setSelectedCategory('bags')} className="hover:text-[#c5a059] transition-colors">حقائب الأعمال واللاب توب</a></li>
              <li><a href="#collection-gallery" onClick={() => setSelectedCategory('accessories')} className="hover:text-[#c5a059] transition-colors">إكسسوارات ومفكرات مكتبية</a></li>
              <li><a href="#collection-gallery" onClick={() => setSelectedCategory('boxes')} className="hover:text-[#c5a059] transition-colors">علب الساعات الفخمة بالبطانة</a></li>
            </ul>
          </div>

          {/* Customer Care Links [Spans 2] */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className="text-xs font-serif uppercase tracking-widest text-white font-bold text-glow">لوائح الورشة</h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#collection-gallery" className="hover:text-[#c5a059] transition-colors">تتبع الشحنات والتحضير</a></li>
              <li><a href="#artist-heritage" className="hover:text-[#c5a059] transition-colors">أصل جودة وتصريح الجلود</a></li>
              <li><a href="#bespoke-studio" className="hover:text-[#c5a059] transition-colors">صيانة الجلد والارتجاع الإجباري</a></li>
              <li><a href="#bespoke-studio" className="hover:text-[#c5a059] transition-colors">صياغة الهدايا والمصنفات</a></li>
            </ul>
          </div>

          {/* Currency reference indicators [Spans 2] */}
          <div className="lg:col-span-2 space-y-4 text-center md:text-right">
            <h4 className="text-xs font-serif uppercase tracking-widest text-white font-bold text-glow">خيارات الدفع والشحن</h4>
            <div className="flex flex-wrap justify-end gap-2 text-[10px] text-stone-500">
              <span className="px-2 py-1 bg-stone-900 rounded border border-stone-850">كريمي تل</span>
              <span className="px-2 py-1 bg-stone-900 rounded border border-stone-850">النجم موبايل</span>
              <span className="px-2 py-1 bg-stone-900 rounded border border-stone-850">خدمة فلوسك</span>
              <span className="px-2 py-1 bg-stone-900 rounded border border-stone-850">كاش يمني / دولار</span>
            </div>
            <div className="text-[10px] text-stone-600 pt-2 leading-relaxed">
              * نقوم بشحن بضائعنا يدوياً باستخدام كبرى شركات الشحن اليمنية المعتمدة لضمان التثبيت والسلامة.
            </div>
          </div>

        </div>

        {/* Copywrite and developer details */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 flex flex-col sm:flex-row justify-between items-center text-xs text-stone-600 dark:text-stone-500 gap-4">
          <p className="text-center sm:text-right">
            حقوق النشر والطبع محفوظة لمشغلات ومتجر <span className="font-bold text-stone-400">HESHAM LEATHER © ٢٠٢٦</span>.
          </p>
          <div className="flex items-center gap-3">
            <span className="font-mono text-[10px]">VER 2.50 | PRODUCTION STATE READY</span>
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 leading-none"></span>
            <span className="font-mono text-stone-600 text-[10px]">صنع بوقار وعناية بالتعاون مع الذكاء الاصطناعي</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
