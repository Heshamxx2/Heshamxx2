export interface Product {
  id: string;
  name: string;
  nameEn: string;
  priceYer: number;
  description: string;
  detailedDescription: string;
  images: string[];
  category: 'wallets' | 'bags' | 'accessories' | 'boxes';
  leatherType: string;
  dimensions: string;
  craftingTime: string;
  rating: number;
  reviewsCount: number;
  badge?: string;
  colors: { name: string; nameAr: string; hex: string }[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor: string;
  customEngraving?: string;
}

export type CurrencyType = 'YER' | 'USD' | 'SAR';

export interface CurrencyConfig {
  code: CurrencyType;
  symbol: string;
  rate: number; // base YER -> desired
  label: string;
}

export interface CustomOrder {
  clientName: string;
  accessoryType: string;
  leatherColor: string;
  engravingText: string;
  details: string;
  urgency: 'normal' | 'express';
}
